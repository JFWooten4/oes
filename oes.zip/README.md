# The Nonpublic Folder

*When uploading files to github.com/sec-gov do not take this "nonpublic" folder (obviously).*

This 'nonpublic' folder preserve all of the internal documentation and "source" code needed.

To rebuild, you should just be able to run shell command

'''cd oes/nonpublic; npm build'''

# Missing features, requirements, bugs, and other issues

*In descending order of relevance, more or less*

The overall package doesn't comply with the new github-publication criteria from Bill (none of our others do either, though).

The validation done by csvalidate.py ("py") and OeReportGenerator.js ("js") are not identical.

* after we get feedback on how they want to handle blanks, infs, and nans, this will have to be checked
* currently empty lines are ignored by js

 Sometimes it seems you have to refresh the .htm page just to process another .csv. This can't be right. Is the issue that the functionss are defined at top level rather than as an attachment to the window?

Neither validator uses the more compact "pattern" attribute syntax from CSVW.

* the "pattern" attribute has syntax that looks like Excel number formats. It is much more compact and easy to understand.
e.g., "#0.00;(#0.00)" to mean two required decimal places and parentheses around negative values.  
* what does it do with NaNs? Can it distinguish negative, positive, and zero?
* is there a compiler that can convert one of those things to a regex with capture groups?

The CSVW Standard is still a draft (!). I looked for existing validators. There are various things in states of disrepair on github.com.  

* Here's an overly elaborate one: [cldf/csvw](https://github.com/cldf/csvw)
* This package: [papaparse](https://www.github.com/mholt/papaparse) is just for reading, and that's all I used.
* For this and other reasons, the oe validators only support the features I used in oes_metadata.json.
* Are we going to be doing more CSV?  Back in 2020 or whenever it was, I felt that we'd be doing more PDF and that's why I enhanced the pdf writer package to handle tagging, so as to make the PDF's Section 508-compliant. 
* Should we do the same for CSV?

Does the one ng test case have coverage?

Does the guide need to spell out the calculations?

# js - OeReportGenerator.js

js does not operate in batch mode. Yes, it could be done with Selenium.  

js has not been tested  in multiple browsers.

js function and variable names don't follow best practices.

js no longer uses jquery, I think, but it's still loaded.

js probably has unused code. 

# py - mockcsv.py, csvalidate.py

Are the py modules going to be published?  No.

* py validator probalby has unused code

* mockcsv isn't ideal as pandas code and could be misleading


